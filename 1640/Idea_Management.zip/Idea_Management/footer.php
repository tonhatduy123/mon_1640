<div id="pageNavPosition" class="text-right"></div>
    <script type="text/javascript">
      var pager = new Pager('myTable', 5);
      pager.init();
      pager.showPageNav('pager', 'pageNavPosition');
      pager.showPage(1);
    </script>
  </div>
  <hr class="hr1" />
  <div class="container-fluid end">
    <div class="row text-center">
      <div class="col-lg-12 link">
        <i class="fab fa-facebook-f"></i>
        <i class="fab fa-instagram"></i>
        <i class="fab fa-youtube"></i>
        <i class="fab fa-google"></i>
      </div>
      <div class="col-lg-12">
        2023 Idea Management | Design by
        <a href="#">Greenwich</a>
      </div>
    </div>
  </div>
  <script src="jquery.min.js"></script>
</body>

</html>